//Sum of two numbers
#include <iostream>
using namespace std;
int main ()
{
    int numOne = 50;
    int numTwo = 100;             
    int total = numOne + numTwo;

    cout << " The sum of "<< numOne << " + " << numTwo << " = " << total << 
    endl;
    return 0;
}

