//Miles per gallon
#include <iostream>
using namespace std;
int main ()
{
    double gallons = 15, miles = 375;
    double mpg = miles / gallons;
    
    cout << "The car gets " << mpg << " miles per gallon" << endl;
    return 0;   
}