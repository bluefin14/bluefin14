//Land calculation
#include <iostream>
using namespace std;
int main ()
{
    double acre = 43560;      		  //1 acre equivalent to 43560 square feet
    double land = 391876;      		  //size of tract of land
    double numberOfAcres = land / acre;
    
    cout << "There are " << numberOfAcres << " acres in " << land << " square feet of land " << endl;
    return 0;
    
}