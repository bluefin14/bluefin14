//Sales prediction
#include <iostream>
using namespace std;
int main ()
{
    double salesdiv = 0.58;                      //58% in sales
    double salesgen = 8.6;                       //$8.6 million in sales
    double salesfinal = salesdiv * salesgen;     //final amount generated
    
    cout << "The East Coast division will generate about: $" << salesfinal << " million" << endl;
    return 0;
}