//Sales tax
#include <iostream>
using namespace std;
int main ()
{
    double purchase = 95;                    //$95 purchase
    double statetax = 0.04*purchase;                  //4% state sales tax
    double countytax = 0.02*purchase;                 //2% county sales tax
    double totaltax = statetax + countytax;  //total tax
    
    cout << "The total sales tax on a $" << purchase << " purchase is: $" 
    << totaltax << endl;
    return 0;
}