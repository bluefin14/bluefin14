//Restaurant bill
#include <iostream>
using namespace std;
int main ()
{
    double meal = 88.67;                //subtotal
    double tax = 0.0675 * meal;         //6.75% tax
    double tip = 0.20 * (meal + tax);   //15% tip
    double total = meal + tax + tip;    //grand total
    
    cout << "The meal cost is: $" << meal << endl;
    cout << "The tax amount is: $" << tax << endl;
    cout << "The tip amount is: $" << tip << endl;
    cout << "The total bill is: $" << total << endl;
    return 0;
}