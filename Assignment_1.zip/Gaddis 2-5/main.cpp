//Average of values
#include <iostream>
using namespace std;
int main ()
{
    int valueOne = 28, valueTwo = 32, valueThree = 37, valueFour = 24, valueFive = 33;  
    int sum = valueOne + valueTwo + valueThree + valueFour + valueFive;                    
    double average = sum / 5;                                                              
    
    cout << "The sum of " << valueOne << " + " << valueTwo << " + " << valueThree << " + " <<valueFour << " + " << valueFive << " = " << sum << " . ";
    cout << "The average is " << average << endl;
    return 0;
}