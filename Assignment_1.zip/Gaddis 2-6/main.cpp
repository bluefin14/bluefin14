//Annual Pay
#include <iostream>
using namespace std;
int main ()
{
    double payAmount = 2200;                        //amount paid each pay period
    double payPeriods = 26;                         //amount of times employee gets paid
    double annualPay = payAmount * payPeriods;      //total amount paid per year
    
    cout << "The employee gets paid $" << payAmount << " each pay period" << endl;
    cout << "There are " << payPeriods <<" pay periods per year" << endl;
    cout << "The employee gets paid $" << annualPay << " per year" << endl;
    return 0;
}