//Ocean levels
#include <iostream>
using namespace std;
int main ()
{
    double currentLevel = 0.00;     //current ocean level in mm
    double risingRate = 1.5;        //rate of rising ocean level in mm
    
    cout << "The ocean's level will be " << risingRate*5 << "mm higher than the current level" << endl;
    cout << "The ocean's level will be " << risingRate*7 << "mm higher than the current level" << endl;
    cout << "The ocean's level will be " << risingRate*10 << "mm higher than the current level" << endl;
    return 0;
}