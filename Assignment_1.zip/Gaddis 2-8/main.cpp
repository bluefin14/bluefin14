//Total purchase
#include <iostream>
using namespace std;
int main ()
{
    double itemOne = 15.95, itemTwo = 24.95, itemThree = 6.95, itemFour = 12.95, itemFive = 3.95;
    double subTotal = itemOne + itemTwo + itemThree + itemFour + itemFive;
    double salesTax = 0.07 * subTotal;
    double total = subTotal + salesTax;
    
    cout << "The price of item one is $" << itemOne << endl;
    cout << "The price of item two is $" << itemTwo << endl;
    cout << "The price of item three is $" << itemThree << endl;
    cout << "The price of item four is $" << itemFour << endl;
    cout << "The price of item five is $" << itemFive << endl;
    cout << "The subtotal is $" << subTotal << endl;
    cout << "The sales  tax is $" << salesTax << endl;
    cout << "The total is $" << total << endl;
    return 0;
}