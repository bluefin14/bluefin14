//Book club points
#include <iostream>
using namespace std;
int main()
{
int books, points;

cout << "Enter the number of books purchased this month ";
cin >> books;

if(books == 0)
{
points = 0;
cout << "You have earned points: " << points <<endl;
}
if(books == 1)
{
points = 5;
cout << "You have earned points : " << points <<endl;
}
if(books == 2)
{
points = 15;
cout << "You have earned points: " << points <<endl;
}
if(books == 3)
{
points = 30;
cout << "You have earned points: " << points <<endl;
}
if(books >= 4)
{
points = 60;
cout << "You have earned points: " << points <<endl;
}
else
{
if(books < 0)
cout << "Number of books cannot be negative!! \n\n";
}
return 0;
}