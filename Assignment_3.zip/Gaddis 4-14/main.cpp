//Bank charges
#include <iostream>
#include <iomanip>
using namespace std;
int main ()
{
    int checks;
    double beginningBalance, feeOne, feeTwo, totalFees;
    
    cout << "Enter beginning balance: $ ";
    cin >> beginningBalance;
    
    cout << setprecision(2) << fixed;
    
    if(beginningBalance < 0)
    cout << "URGENT MESSAGE!! YOUR ACCOUNT IS OVERDRAWN!! \n\n";
    else
    {
     cout << "Enter number of checks written: ";
    cin >> checks;
 
    if(beginningBalance < 400)
    feeOne = 15.00;
    else
    feeOne = 0.00;

    if(checks >= 0 && checks < 20)
    feeTwo = checks * 0.10;
    if(checks >= 20 && checks <= 39)
    feeTwo = checks * 0.08;
    if(checks >= 40 && checks <= 59)
    feeTwo = checks * 0.06;
    if(checks >= 60)
    feeTwo = checks * 0.04;
    if(checks < 0)
    cout << "The number of checks cannot be negative ";

    totalFees = feeOne + feeTwo;

    cout << "Low Balance fee: $" << feeOne;
    cout << "Check fees: $" << feeTwo;
    cout << "Total Monthly fees: $" << totalFees;
    }
    return 0;
}