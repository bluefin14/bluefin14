#include<iostream>
using namespace std;
int main()
{
    int number;
    
    cout << "Enter a number (1-10) ";
    cin >> number;
    
    if (number < 1 || number > 10)
        cout << "Invalid number entered. Number cannot be less than 1 or greater than 10";
    else{
 switch(number)
 {
 case 1: cout << "The Roman numeral is: I ";
   break;
 case 2: cout << "The Roman numeral is: II ";
   break;
 case 3: cout << "The Roman numeral is: III ";
   break;
 case 4: cout << "The Roman numeral is: IV ";
   break;
 case 5: cout << "The Roman numeral is: V ";
   break;
 case 6: cout << "The Roman numeral is: VI ";
   break;
 case 7: cout << "The Roman numeral is: VII ";
   break;
 case 8: cout << "The Roman numeral is: VIII ";
   break;
 case 9: cout << "The Roman numeral is: IX ";
   break;
 case 10: cout << "The Roman numeral is: X ";
   break;
 default:  cout << "Enter a number between 1-10 ";
 }
 }
 return 0;
}
 