//Areas of rectangles
#include <iostream>
using namespace std;
int main ()
{
    double length1, length2, width1, width2, area1, area2;
    
    cout << " Enter the length of rectangle 1 ";
    cin >> length1;
    cout << " Enter the width of rectangle 1 ";
    cin >> width1;
    cout << " Enter the length of rectangle 2 ";
    cin >> length2;
    cout << " Enter the width of rectangle 2 ";
    cin >> width2;
    
    area1 = length1 * width1;
    area2 = length2 * width2;
    
    if (area1 > area2)
        cout << " The area of rectangle 1 is greater than rectangle 2 " << endl;
    else if (area2 > area1)
        cout << " The area of rectangle 2 is greater than rectangle 1 " << endl;
    else if (area1 = area2)
        cout << "The area of rectangle 1 and rectangle 2 is the same " << endl;
    return 0;
}