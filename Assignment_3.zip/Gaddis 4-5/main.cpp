//Body mass index
#include <iostream>
using namespace std;
int main ()
{
    double weight, height, bmi;
    
    cout << " Enter weight (in pounds) ";
    cin >> weight;
    cout << " Enter height (in inches) ";
    cin >> height;
    
    bmi = (weight * 703) / (height * height);
    
    if (bmi < 18.5)
        cout << " You are underweight ";
    if (bmi >= 18.5 && bmi <= 25)
        cout << " You are in good shape ";
    if (bmi > 25)
        cout << " You are overweight ";
    return 0;
}