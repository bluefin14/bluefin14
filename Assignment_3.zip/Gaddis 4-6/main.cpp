//Mass and weight
#include <iostream>
using namespace std;
int main ()
{
    double mass, weight;
    
    cout << "Enter the mass of an object (in kg)";
    cin >> mass;
    
    weight = mass * 9.8;
    
    if (weight > 1000)
    {
        cout << "The mass is " << weight << " Newtons";
        cout << "The mass of the object is too heavy";
    }
    if (weight < 10)
    {
        cout << "The mass is " << weight << " Newtons";
        cout << "The mass of the object is too light";
    }
    if (weight >= 10 && weight <= 1000)
    {
        cout << "The mass is " << weight << " Newtons";
    }
    return 0;
}