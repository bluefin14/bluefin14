//Time calculator
#include <iostream>
#include <iomanip>
using namespace std;
int main ()
{
    double seconds, hour, day;
    hour = 3600;
    day = 86400;
    
    cout << "Enter the number of seconds ";
    cin >> seconds;
    
    cout << setprecision(2) << fixed;
    if (seconds >= 86400)
        cout << "The seconds you entered = " << seconds/86400 << " days";
    if (seconds >= 3600)
        cout << "The seconds you entered = " << seconds/3600 << " hours";
    if (seconds>=60)
        cout << "The seoncds you entered = " << seconds/60 << " minutes";
    if (seconds < 60 && seconds > 0)
        cout << "The seconds you entered = " << seconds << " seconds";
    return 0;
}