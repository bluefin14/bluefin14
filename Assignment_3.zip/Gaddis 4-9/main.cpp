//Change for a dollar game
#include <iostream>
#include <iomanip>
using namespace std;
int main ()
{
    double pennies, nickels, dimes, quarters, total;
    
    cout << "Enter the number of pennies ";
    cin >> pennies;
    cout << "Enter the number of nickels ";
    cin >> nickels;
    cout << "Enter the number of dimes ";
    cin >> dimes;
    cout << "Enter the number of quarters ";
    cin >> quarters;
    
    total = (pennies * 0.01) + (nickels * 0.05) + (dimes * 0.10) + (quarters * 0.25);
    
    if (total == 1.00)
        cout << "You win!";
    else
    {
        if (total < 1.00 && total > 0)
            cout << "You lose!";
        if (total > 1.00)
            cout << "You lose!";
    }
    return 0;
}