//Miles per gallon
#include <iostream>
using namespace std;
int main ()
{
    double capacity, miles, average;
    
    cout << "Enter the number of gallons of gas the car can hold";
    cin >> capacity;
    cout << "Enter the number of miles that can be driven on a full tank";
    cin >> miles;
    
    average = miles/capacity;
    
    cout << "The car's miles per gallon is: " << average << endl;
    return 0;
}