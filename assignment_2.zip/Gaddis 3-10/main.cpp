//How much insurance?
#include <iostream>
using namespace std;
int main ()
{
    double replacementCost;
    
    cout << "Enter the replacement cost of the property";
    cin >> replacementCost;
    
    cout << "The minimum amount of insurance you should buy for the property is: $ " << replacementCost * 0.80 << endl;
    return 0;
}