//Celsius to Fahrenheit
#include <iostream>
using namespace std;
int main ()
{
    double Celsius, conversion;
    
    cout << "Enter Celsius temperature ";
    cin >> Celsius;
    
    conversion = (1.8 * Celsius) + 32;
    
    cout << Celsius << " Celsius is equivalent to " << conversion << " Fahrenheit " << endl;
    return 0;
}