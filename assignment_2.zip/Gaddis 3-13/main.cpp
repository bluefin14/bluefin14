//Currency
#include <iostream>
#include <iomanip>
using namespace std;
int main ()
{
    const double YEN_PER_DOLLAR = 98.93;
    const double EUROS_PER_DOLLAR = 0.74;
    
    double dollars, yen, euros;
    
    cout << setprecision(2) << fixed;
    cout << "Enter dollar amount ";
    cin >> dollars;
    
    yen = dollars * YEN_PER_DOLLAR;
    euros = dollars * EUROS_PER_DOLLAR;
    
    cout << " $ " << dollars << " = " << yen << " yen ";
    cout << " $ " << dollars << " = " << euros << "euros";
    return 0;
}