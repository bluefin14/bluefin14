//Stadium seating
#include <iostream>
#include <iomanip>
using namespace std;
int main ()
{
    double classA = 15, classB = 12, classC = 9;
    double numberA, numberB, numberC;
    double total;
    
    cout << "How many tickets were sold for class A?";
    cin >> numberA;
    cout << "How many tickets were sold for class B?";
    cin >> numberB;
    cout << "How many tickets were sold for class C?";
    cin >> numberC;
    
    cout << setprecision(2) << fixed;
    cout << "Sales from class A: $ " << numberA * classA << endl;
    cout << "Sales from class B: $ " << numberB * classB << endl;
    cout << "Sales from class C: $ " << numberC * classC << endl;
    
    total = (numberA*classA) + (numberB*classB) + (numberC*classC);
    
    cout << "Income generated from ticket sales: $ " << total << endl;
    return 0;
}