//Pizza pi
#include <iostream>
#include <iomanip>
using namespace std;
int main ()
{
    double diameter, radius, slices, area;
    double const pi = 3.14159;
    
    cout << "Enter the diameter of the pizza (in inches) ";
    cin >> diameter;
    
    radius = diameter / 2;
    area = pi * radius * radius;
    slices = area / 14.125;
    
    cout << setprecision(1) << fixed;
    cout << "There are " << slices << "slices on this pizza." << endl;
    return 0;
}