//How many widgets?
#include <iostream>
#include <iomanip>
using namespace std;
int main ()
{
    double widgetWeight = 12.5;     //in pounds
    double palletEmpty, palletWeight;
    double widgetNumber;
    
    cout << "How much does the pallet weigh by itself (in pounds)?";
    cin >> palletEmpty;
    cout << "How much does the pallet weigh (in pounds) with widgets?";
    cin >> palletWeight;
    
    widgetNumber = (palletWeight - palletEmpty)/12.5;
    
    cout << "There are " << widgetNumber << "widgets on the pallet.";
    return 0;
}