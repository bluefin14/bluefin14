//How many calories?
#include <iostream>
using namespace std;
int main ()
{
    double cookies, totalCalories;
    
    cout << "Enter the number of cookies consumed";
    cin >> cookies;
    
    /*
     30 cookies = 10 servings
     3 cookies = 1 serving (300 calories)
     1 cookie = 1/3 serving (100 calories)
     */
    
    totalCalories = cookies * 33;
    
    cout << "You consumed " << totalCalories << "calories" << endl;
    return 0;
}
